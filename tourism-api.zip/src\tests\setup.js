const dotenv = require('dotenv');
const path = require('path');
const mongoose = require('mongoose');
const redisClient = require('../config/redis');

// Load test environment variables
dotenv.config({ path: path.join(__dirname, '../config/test.env') });

// Set test environment
process.env.NODE_ENV = 'test';

// Mock Redis class
jest.mock('ioredis', () => {
    return jest.fn().mockImplementation(() => ({
        get: jest.fn(),
        set: jest.fn(),
        setex: jest.fn(),
        del: jest.fn(),
        flushall: jest.fn(),
        quit: jest.fn(),
        on: jest.fn(),
        connect: jest.fn(),
        disconnect: jest.fn()
    }));
});

// Mock nodemailer
jest.mock('nodemailer', () => ({
    createTransport: jest.fn().mockReturnValue({
        sendMail: jest.fn().mockResolvedValue({ response: 'Success' })
    })
}));

// Mock twilio
jest.mock('twilio', () => () => ({
    messages: {
        create: jest.fn().mockResolvedValue({ sid: 'test-sid' })
    }
}));

// Mock web-push
jest.mock('web-push', () => ({
    setVapidDetails: jest.fn(),
    sendNotification: jest.fn().mockResolvedValue()
}));

// Mock file upload
jest.mock('express-fileupload', () => () => (req, res, next) => {
    if (req.files) {
        req.files.avatar = {
            name: 'test-avatar.jpg',
            data: Buffer.from('test'),
            size: 1024,
            mimetype: 'image/jpeg'
        };
    }
    next();
});

// Mock Redis for testing
jest.mock('../config/redis', () => ({
    get: jest.fn(),
    set: jest.fn(),
    setex: jest.fn(),
    del: jest.fn(),
    flushall: jest.fn(),
    quit: jest.fn()
}));

// Increase timeout for all tests
jest.setTimeout(30000);

// Mock console.error to avoid noise in test output
console.error = jest.fn();
console.warn = jest.fn();

// Global test helpers
global.createTestUser = async (userData = {}) => {
    const User = mongoose.model('User');
    const defaultUser = {
        firstName: 'Test',
        lastName: 'User',
        email: 'test@example.com',
        password: 'password123',
        role: 'user'
    };
    return await User.create({ ...defaultUser, ...userData });
};

global.generateAuthToken = async (user) => {
    return user.generateAuthToken();
};

// Global beforeAll
beforeAll(async () => {
    console.log('🚀 Starting test suite');
    // Connect to test database
    try {
        await mongoose.connect(process.env.MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('✅ Connected to test database');
    } catch (error) {
        console.error('❌ Failed to connect to test database:', error);
        throw error;
    }
});

// Global beforeEach
beforeEach(async () => {
    console.log('\n🔄 Resetting test state');
    try {
        // Clear all collections
        const collections = mongoose.connection.collections;
        for (const key in collections) {
            await collections[key].deleteMany();
        }
        console.log('✅ Cleared all collections');
        
        // Reset all mocks
        jest.clearAllMocks();
        console.log('✅ Reset all mocks');
    } catch (error) {
        console.error('❌ Failed to reset test state:', error);
        throw error;
    }
});

// Global afterAll
afterAll(async () => {
    console.log('\n🏁 Cleaning up test suite');
    try {
        // Close database connection
        await mongoose.connection.close();
        console.log('✅ Closed database connection');
        
        // Close Redis connection
        if (redisClient) {
            await redisClient.quit();
            console.log('✅ Closed Redis connection');
        }
    } catch (error) {
        console.error('❌ Failed to clean up:', error);
        throw error;
    }
}); 