// Authentication state management
class AuthManager {
    constructor() {
        this.token = localStorage.getItem('token');
        this.user = JSON.parse(localStorage.getItem('user'));
        this.tokenExpiryTime = localStorage.getItem('tokenExpiryTime');
        this.refreshTokenTimeout = null;
    }

    isAuthenticated() {
        return !!this.token && this.isTokenValid();
    }

    isTokenValid() {
        if (!this.tokenExpiryTime) return false;
        return new Date().getTime() < parseInt(this.tokenExpiryTime);
    }

    setSession(token, user) {
        // Set token expiry to 24 hours from now
        const expiryTime = new Date().getTime() + (24 * 60 * 60 * 1000);
        
        this.token = token;
        this.user = user;
        this.tokenExpiryTime = expiryTime;

        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('tokenExpiryTime', expiryTime);

        // Set up auto refresh 5 minutes before token expires
        this.setupAutoRefresh(expiryTime);
    }

    clearSession() {
        this.token = null;
        this.user = null;
        this.tokenExpiryTime = null;

        localStorage.removeItem('token');
        localStorage.removeItem('user');
        localStorage.removeItem('tokenExpiryTime');

        if (this.refreshTokenTimeout) {
            clearTimeout(this.refreshTokenTimeout);
        }
    }

    setupAutoRefresh(expiryTime) {
        if (this.refreshTokenTimeout) {
            clearTimeout(this.refreshTokenTimeout);
        }

        const timeUntilRefresh = expiryTime - new Date().getTime() - (5 * 60 * 1000); // 5 minutes before expiry
        if (timeUntilRefresh > 0) {
            this.refreshTokenTimeout = setTimeout(() => this.refreshToken(), timeUntilRefresh);
        }
    }

    async refreshToken() {
        try {
            const response = await fetch('/api/v1/auth/refresh-token', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            if (!response.ok) throw new Error('Token refresh failed');

            const data = await response.json();
            this.setSession(data.token, data.user);
        } catch (error) {
            console.error('Error refreshing token:', error);
            this.clearSession();
            window.location.href = '/signin.html';
        }
    }

    async login(email, password) {
        try {
            const response = await fetch('/api/v1/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Login failed');
            }

            this.setSession(data.token, data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async register(userData) {
        try {
            const response = await fetch('/api/v1/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Registration failed');
            }

            this.setSession(data.token, data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async logout() {
        try {
            if (this.token) {
                await fetch('/api/v1/auth/logout', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${this.token}`
                    }
                });
            }
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.clearSession();
            window.location.href = '/signin.html';
        }
    }

    updateUser(userData) {
        this.user = { ...this.user, ...userData };
        localStorage.setItem('user', JSON.stringify(this.user));
    }

    getAuthHeaders() {
        return {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
        };
    }

    async googleAuth(idToken) {
        try {
            const response = await fetch('/api/v1/auth/google', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ idToken })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Google authentication failed');
            }

            this.setSession(data.token, data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async facebookAuth(accessToken) {
        try {
            const response = await fetch('/api/v1/auth/facebook', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ accessToken })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Facebook authentication failed');
            }

            this.setSession(data.token, data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async appleAuth(identityToken) {
        try {
            const response = await fetch('/api/v1/auth/apple', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ identityToken })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Apple authentication failed');
            }

            this.setSession(data.token, data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async linkSocialAccount(provider, token) {
        try {
            const response = await fetch(`/api/v1/auth/link/${provider}`, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify({ token })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `Failed to link ${provider} account`);
            }

            this.updateUser(data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    async unlinkSocialAccount(provider) {
        try {
            const response = await fetch(`/api/v1/auth/unlink/${provider}`, {
                method: 'POST',
                headers: this.getAuthHeaders()
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `Failed to unlink ${provider} account`);
            }

            this.updateUser(data.user);
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
}

// Create a singleton instance
const auth = new AuthManager();

// Check authentication state on page load
document.addEventListener('DOMContentLoaded', () => {
    if (!auth.isAuthenticated()) {
        const currentPage = window.location.pathname;
        const publicPages = ['/signin.html', '/signup.html', '/forgot-password.html'];
        
        if (!publicPages.includes(currentPage)) {
            window.location.href = '/signin.html';
        }
    }
});

// Export the singleton instance
window.auth = auth; 