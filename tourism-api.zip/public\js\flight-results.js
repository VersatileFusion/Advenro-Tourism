document.addEventListener('DOMContentLoaded', function() {
    // Get search parameters from URL
    const params = new URLSearchParams(window.location.search);
    const searchData = {
        from: params.get('from'),
        to: params.get('to'),
        departure: params.get('departure'),
        return: params.get('return'),
        passengers: params.get('passengers'),
        class: params.get('class')
    };

    // Handle check button clicks
    const checkButtons = document.querySelectorAll('.check-btn');
    checkButtons.forEach(button => {
        button.addEventListener('click', function() {
            const flightCard = this.closest('.flight-card');
            const flightData = {
                airline: flightCard.querySelector('.airline-logo').alt,
                flightNumber: flightCard.querySelector('.fw-500').textContent,
                departure: {
                    time: flightCard.querySelector('.col-5:first-child .time').textContent,
                    location: flightCard.querySelector('.col-5:first-child .location').textContent
                },
                arrival: {
                    time: flightCard.querySelector('.col-5:last-child .time').textContent,
                    location: flightCard.querySelector('.col-5:last-child .location').textContent
                },
                duration: flightCard.querySelector('.duration').textContent,
                class: flightCard.querySelector('.text-muted:last-child').textContent,
                price: flightCard.querySelector('.price').textContent
            };

            // Store flight data in session storage
            sessionStorage.setItem('selectedFlight', JSON.stringify(flightData));
            
            // Redirect to seat selection page
            window.location.href = 'seat-selection.html';
        });
    });
}); 