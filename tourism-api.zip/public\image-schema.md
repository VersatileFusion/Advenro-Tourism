# Image and Icon Schema

## Airlines Directory (`public/images/airlines/`)
- `indigo.png` - Indigo Airlines logo (24x24px)
- `delta.png` - Delta Airlines logo (24x24px)

## Payment Methods Directory (`public/images/payment/`)
- `mastercard.png` - Mastercard logo (24x24px)
- `visa.png` - Visa logo (24x24px)
- `amex.png` - American Express logo (24x24px)
- `paypal.png` - PayPal logo (24x24px)

## Avatars Directory (`public/images/avatars/`)
- `default.jpg` - Default user avatar (48x48px)

## Existing Icons (`public/icons/`)
These icons can be used in the flight booking flow:
- `home-icon.png` - For navigation
- `mytrip-icon.png` - For bookings section
- `ticket-icon.png` - For boarding passes
- `profile-icon.png` - For user profile

## Image Usage in Files

### flight-results.html
```html
<img src="images/airlines/indigo.png" alt="Indigo" class="airline-logo">
<img src="images/airlines/delta.png" alt="Delta" class="airline-logo">
```

### payment.html
```html
<img src="images/airlines/indigo.png" alt="Indigo" class="airline-logo">
<img src="images/payment/mastercard.png" alt="Mastercard">
<img src="images/payment/visa.png" alt="Visa">
<img src="images/payment/amex.png" alt="American Express">
<img src="images/payment/paypal.png" alt="PayPal">
```

### boarding-pass.html
```html
<img src="images/avatars/default.jpg" alt="Passenger" class="passenger-avatar">
<img src="images/airlines/indigo.png" alt="Indigo" class="airline-logo">
```

## Image Specifications

### Airline Logos
- Size: 24x24 pixels
- Format: PNG with transparency
- Usage: Flight cards, boarding passes

### Payment Method Icons
- Size: 24x24 pixels
- Format: PNG with transparency
- Background: Transparent
- Style: Monochrome with opacity states (0.6 normal, 1.0 hover)

### Avatar Images
- Size: 48x48 pixels
- Format: JPG/PNG
- Style: Square with border-radius: 50% applied via CSS

### Navigation Icons
- Size: 24x24 pixels
- Format: PNG with transparency
- Color: Should match the primary color (#ff0509) 