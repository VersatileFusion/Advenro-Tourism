// Social Authentication Configuration
const socialAuth = {
    google: {
        clientId: 'YOUR_GOOGLE_CLIENT_ID', // Replace with your Google Client ID
        init() {
            return new Promise((resolve) => {
                gapi.load('auth2', () => {
                    gapi.auth2.init({
                        client_id: this.clientId
                    }).then(resolve);
                });
            });
        },
        async signIn() {
            try {
                const googleAuth = gapi.auth2.getAuthInstance();
                const googleUser = await googleAuth.signIn();
                const idToken = googleUser.getAuthResponse().id_token;
                return await auth.googleAuth(idToken);
            } catch (error) {
                return {
                    success: false,
                    error: error.message || 'Google sign in failed'
                };
            }
        }
    },

    facebook: {
        appId: 'YOUR_FACEBOOK_APP_ID', // Replace with your Facebook App ID
        init() {
            return new Promise((resolve) => {
                FB.init({
                    appId: this.appId,
                    cookie: true,
                    xfbml: true,
                    version: 'v18.0'
                });
                resolve();
            });
        },
        async signIn() {
            try {
                const response = await new Promise((resolve, reject) => {
                    FB.login((response) => {
                        if (response.authResponse) {
                            resolve(response);
                        } else {
                            reject(new Error('Facebook login cancelled'));
                        }
                    }, { scope: 'email,public_profile' });
                });

                return await auth.facebookAuth(response.authResponse.accessToken);
            } catch (error) {
                return {
                    success: false,
                    error: error.message || 'Facebook sign in failed'
                };
            }
        }
    },

    apple: {
        clientId: 'YOUR_APPLE_CLIENT_ID', // Replace with your Apple Client ID
        async signIn() {
            try {
                const response = await AppleID.auth.signIn();
                return await auth.appleAuth(response.authorization.id_token);
            } catch (error) {
                return {
                    success: false,
                    error: error.message || 'Apple sign in failed'
                };
            }
        }
    },

    async initialize() {
        // Load Google Sign-In SDK
        const googleScript = document.createElement('script');
        googleScript.src = 'https://apis.google.com/js/platform.js';
        googleScript.async = true;
        googleScript.defer = true;
        document.head.appendChild(googleScript);

        // Load Facebook SDK
        const fbScript = document.createElement('script');
        fbScript.src = 'https://connect.facebook.net/en_US/sdk.js';
        fbScript.async = true;
        fbScript.defer = true;
        document.head.appendChild(fbScript);

        // Load Apple Sign-In SDK
        const appleScript = document.createElement('script');
        appleScript.src = 'https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/en_US/appleid.auth.js';
        appleScript.async = true;
        appleScript.defer = true;
        document.head.appendChild(appleScript);

        // Initialize SDKs
        await Promise.all([
            this.google.init(),
            this.facebook.init()
        ]);
    }
};

// Initialize social authentication when the page loads
document.addEventListener('DOMContentLoaded', () => {
    socialAuth.initialize().catch(console.error);
}); 