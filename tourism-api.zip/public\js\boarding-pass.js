document.addEventListener('DOMContentLoaded', function() {
    // Get flight data from session storage
    const flightData = JSON.parse(sessionStorage.getItem('selectedFlight') || '{}');
    
    // Update boarding pass information
    if (flightData.airline) {
        document.querySelector('.airline-logo').src = `images/airlines/${flightData.airline.toLowerCase()}.png`;
    }
    if (flightData.departure) {
        document.querySelector('.col-5:first-child .time').textContent = flightData.departure.time;
        document.querySelector('.col-5:first-child .location').textContent = flightData.departure.location;
    }
    if (flightData.arrival) {
        document.querySelector('.col-5:last-child .time').textContent = flightData.arrival.time;
        document.querySelector('.col-5:last-child .location').textContent = flightData.arrival.location;
    }
    if (flightData.flightNumber) {
        document.querySelector('.info-item:nth-child(1) .info-value').textContent = flightData.flightNumber;
    }
    if (flightData.seat) {
        document.querySelector('.info-item:nth-child(3) .info-value').textContent = flightData.seat;
    }
    if (flightData.class) {
        document.querySelector('.info-item:nth-child(4) .info-value').textContent = flightData.class;
    }

    // Generate barcode
    const barcodeNumber = document.querySelector('.barcode-number').textContent;
    JsBarcode("#barcode", barcodeNumber, {
        format: "CODE128",
        width: 2,
        height: 60,
        displayValue: false
    });

    // Handle download button
    const downloadButton = document.querySelector('.download-btn');
    downloadButton.addEventListener('click', function() {
        // Create a clone of the boarding pass for PDF
        const boardingPass = document.querySelector('.boarding-pass').cloneNode(true);
        boardingPass.style.margin = '0';
        boardingPass.style.padding = '24px';
        
        // Create a container for the PDF
        const container = document.createElement('div');
        container.style.width = '400px';
        container.style.padding = '0';
        container.style.background = 'white';
        container.appendChild(boardingPass);
        
        // Convert to PDF using html2pdf
        const opt = {
            margin: 0,
            filename: 'boarding-pass.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };

        // Simulate download (in real app, use html2pdf.js)
        setTimeout(() => {
            alert('Boarding pass downloaded successfully!');
        }, 1000);
    });

    // Add to My Bookings
    const bookingData = {
        ...flightData,
        bookingId: barcodeNumber,
        status: 'Confirmed',
        bookingDate: new Date().toISOString()
    };

    // Get existing bookings or initialize empty array
    const existingBookings = JSON.parse(localStorage.getItem('myBookings') || '[]');
    existingBookings.push(bookingData);
    localStorage.setItem('myBookings', JSON.stringify(existingBookings));
}); 