// Initialize all tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
});

// Initialize all popovers
var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl)
});

// Handle filter panel
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Swiper for category tags
    const categorySwiper = new Swiper('.category-swiper', {
        slidesPerView: 'auto',
        spaceBetween: 12,
        freeMode: true,
        grabCursor: true,
        resistance: true,
        resistanceRatio: 0.65,
        watchSlidesProgress: true,
        touchRatio: 1,
        touchAngle: 45,
        preventClicks: true,
        preventClicksPropagation: true,
        touchMoveStopPropagation: true,
        on: {
            init: function() {
                // Add active class to first slide
                this.slides[0].classList.add('active');
            },
            slideChange: function() {
                // Update active class
                this.slides.forEach(slide => slide.classList.remove('active'));
                this.slides[this.activeIndex].classList.add('active');
            }
        }
    });

    // Initialize all offcanvas elements
    const offcanvasElements = document.querySelectorAll('.offcanvas');
    offcanvasElements.forEach(function(offcanvasEl) {
        new bootstrap.Offcanvas(offcanvasEl, {
            backdrop: true,
            keyboard: true,
            scroll: true
        });
    });

    // Handle filter button clicks
    const filterButtons = document.querySelectorAll('.btn-outline-secondary');
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons in the same group
            const parent = this.parentElement;
            parent.querySelectorAll('.btn-outline-secondary').forEach(btn => {
                btn.classList.remove('active');
            });
            // Add active class to clicked button
            this.classList.add('active');
        });
    });
}); 