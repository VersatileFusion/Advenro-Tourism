// Initialize date pickers
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Flatpickr for departure and return dates
    const today = new Date();
    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + 12);

    // Common configuration for date pickers
    const dateConfig = {
        minDate: 'today',
        maxDate: maxDate,
        altInput: true,
        altFormat: 'F j, Y',
        dateFormat: 'Y-m-d',
        disableMobile: true
    };

    // Departure date picker
    const departurePicker = flatpickr('#departure-date', {
        ...dateConfig,
        onChange: function(selectedDates) {
            // Update return date min date
            if (selectedDates[0]) {
                returnPicker.set('minDate', selectedDates[0]);
            }
        }
    });

    // Return date picker
    const returnPicker = flatpickr('#return-date', {
        ...dateConfig,
        minDate: today
    });

    // Handle trip type changes
    const tripTypeInputs = document.querySelectorAll('input[name="trip-type"]');
    const returnDateGroup = document.querySelector('#return-date').closest('.col-6');

    tripTypeInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.id === 'one-way') {
                returnDateGroup.style.display = 'none';
                document.querySelector('#return-date').value = '';
            } else if (this.id === 'round-trip') {
                returnDateGroup.style.display = 'block';
            } else if (this.id === 'multi-city') {
                // TODO: Implement multi-city UI
                alert('Multi-city booking coming soon!');
                document.querySelector('#round-trip').checked = true;
                returnDateGroup.style.display = 'block';
            }
        });
    });
});

// Handle passenger selection
document.addEventListener('DOMContentLoaded', function() {
    const passengerTrigger = document.getElementById('passenger-trigger');
    const passengerDropdown = document.getElementById('passenger-dropdown');
    const passengerDisplay = document.getElementById('passenger-display');
    const cabinClass = document.getElementById('cabin-class');

    // Toggle passenger dropdown
    passengerTrigger.addEventListener('click', function() {
        passengerDropdown.classList.toggle('show');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (!passengerTrigger.contains(event.target) && !passengerDropdown.contains(event.target)) {
            passengerDropdown.classList.remove('show');
        }
    });

    // Handle passenger count buttons
    const countButtons = document.querySelectorAll('.count-btn');
    countButtons.forEach(button => {
        button.addEventListener('click', function() {
            const type = this.dataset.type;
            const action = this.dataset.action;
            const countElement = document.getElementById(`${type}-count`);
            let count = parseInt(countElement.textContent);

            if (action === 'increase') {
                if (type === 'adult' && count < 9) count++;
                else if (type !== 'adult' && count < 4) count++;
            } else if (action === 'decrease') {
                if (type === 'adult' && count > 1) count--;
                else if (type !== 'adult' && count > 0) count--;
            }

            countElement.textContent = count;
            updatePassengerDisplay();
        });
    });

    // Handle cabin class changes
    cabinClass.addEventListener('change', updatePassengerDisplay);

    function updatePassengerDisplay() {
        const adults = parseInt(document.getElementById('adult-count').textContent);
        const children = parseInt(document.getElementById('child-count').textContent);
        const infants = parseInt(document.getElementById('infant-count').textContent);
        const selectedClass = cabinClass.options[cabinClass.selectedIndex].text;

        let displayText = '';
        const total = adults + children + infants;

        if (total === 1) {
            displayText = `1 Adult`;
        } else {
            const parts = [];
            if (adults) parts.push(`${adults} Adult${adults > 1 ? 's' : ''}`);
            if (children) parts.push(`${children} Child${children > 1 ? 'ren' : ''}`);
            if (infants) parts.push(`${infants} Infant${infants > 1 ? 's' : ''}`);
            displayText = parts.join(', ');
        }

        displayText += `, ${selectedClass}`;
        passengerDisplay.value = displayText;
    }
});

// Handle flight search
document.addEventListener('DOMContentLoaded', function() {
    const searchButton = document.getElementById('search-flights');
    const spinner = searchButton.querySelector('.spinner-border');
    const fromCity = document.getElementById('from-city');
    const toCity = document.getElementById('to-city');
    const departureDate = document.getElementById('departure-date');
    const returnDate = document.getElementById('return-date');

    searchButton.addEventListener('click', async function() {
        // Validate inputs
        if (!fromCity.value) {
            alert('Please select departure city');
            fromCity.focus();
            return;
        }
        if (!toCity.value) {
            alert('Please select destination city');
            toCity.focus();
            return;
        }
        if (!departureDate.value) {
            alert('Please select departure date');
            departureDate.focus();
            return;
        }
        if (document.getElementById('round-trip').checked && !returnDate.value) {
            alert('Please select return date');
            returnDate.focus();
            return;
        }

        // Show loading state
        searchButton.disabled = true;
        spinner.classList.remove('d-none');
        searchButton.querySelector('span:not(.spinner-border)').textContent = 'Searching...';

        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Redirect to results page
            const params = new URLSearchParams({
                from: fromCity.value,
                to: toCity.value,
                departure: departureDate.value,
                return: returnDate.value || '',
                passengers: document.getElementById('passenger-display').value,
                class: document.getElementById('cabin-class').value
            });
            
            window.location.href = `flight-results.html?${params.toString()}`;
        } catch (error) {
            alert('An error occurred while searching for flights. Please try again.');
        } finally {
            // Reset button state
            searchButton.disabled = false;
            spinner.classList.add('d-none');
            searchButton.querySelector('span:not(.spinner-border)').textContent = 'Search Flights';
        }
    });
}); 