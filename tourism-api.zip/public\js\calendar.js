// Calendar functionality
class Calendar {
    constructor() {
        this.currentDate = new Date();
        this.selectedDate = null;
        this.daysContainer = document.querySelector('.days');
        this.monthDisplay = document.querySelector('.calendar-nav span');
        this.prevButton = document.querySelector('.calendar-nav .btn-link:first-child');
        this.nextButton = document.querySelector('.calendar-nav .btn-link:last-child');
        
        this.init();
    }

    init() {
        this.renderCalendar();
        this.setupEventListeners();
    }

    renderCalendar() {
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();
        
        // Update month display
        this.monthDisplay.textContent = this.currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
        
        // Get first day of month and total days
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const totalDays = lastDay.getDate();
        
        // Clear previous days
        this.daysContainer.innerHTML = '';
        
        // Add empty cells for days before first day of month
        for (let i = 0; i < firstDay.getDay(); i++) {
            this.daysContainer.appendChild(this.createDayElement(''));
        }
        
        // Add days of the month
        for (let day = 1; day <= totalDays; day++) {
            const date = new Date(year, month, day);
            const isToday = this.isToday(date);
            const isSelected = this.isSelected(date);
            const isDisabled = this.isDisabled(date);
            
            this.daysContainer.appendChild(this.createDayElement(day, isToday, isSelected, isDisabled));
        }
    }

    createDayElement(day, isToday = false, isSelected = false, isDisabled = false) {
        const div = document.createElement('div');
        div.className = 'day';
        
        if (isToday) div.classList.add('today');
        if (isSelected) div.classList.add('selected');
        if (isDisabled) div.classList.add('disabled');
        
        const span = document.createElement('span');
        span.textContent = day;
        
        if (!isDisabled && day) {
            div.addEventListener('click', () => this.selectDate(new Date(this.currentDate.getFullYear(), this.currentDate.getMonth(), day)));
        }
        
        div.appendChild(span);
        return div;
    }

    setupEventListeners() {
        this.prevButton.addEventListener('click', () => {
            this.currentDate.setMonth(this.currentDate.getMonth() - 1);
            this.renderCalendar();
        });
        
        this.nextButton.addEventListener('click', () => {
            this.currentDate.setMonth(this.currentDate.getMonth() + 1);
            this.renderCalendar();
        });
    }

    selectDate(date) {
        this.selectedDate = date;
        this.renderCalendar();
        
        // Update time slots availability
        this.updateTimeSlots(date);
    }

    isToday(date) {
        const today = new Date();
        return date.getDate() === today.getDate() &&
               date.getMonth() === today.getMonth() &&
               date.getFullYear() === today.getFullYear();
    }

    isSelected(date) {
        if (!this.selectedDate) return false;
        return date.getDate() === this.selectedDate.getDate() &&
               date.getMonth() === this.selectedDate.getMonth() &&
               date.getFullYear() === this.selectedDate.getFullYear();
    }

    isDisabled(date) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return date < today;
    }

    updateTimeSlots(date) {
        const timeSlots = document.querySelectorAll('.time-slot');
        const isToday = this.isToday(date);
        const now = new Date();
        
        timeSlots.forEach(slot => {
            const time = slot.textContent;
            const [hours, minutes] = time.split(':').map(Number);
            const slotDate = new Date(date);
            slotDate.setHours(hours, minutes, 0, 0);
            
            if (isToday && slotDate < now) {
                slot.disabled = true;
                slot.classList.add('disabled');
            } else {
                slot.disabled = false;
                slot.classList.remove('disabled');
            }
        });
    }
}

// Time slot selection
document.querySelectorAll('.time-slot').forEach(slot => {
    slot.addEventListener('click', function() {
        if (!this.disabled) {
            document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('active'));
            this.classList.add('active');
        }
    });
});

// Initialize calendar
document.addEventListener('DOMContentLoaded', () => {
    new Calendar();
}); 