// Handle like button clicks with animation
document.querySelectorAll('.btn-like').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        const icon = this.querySelector('i');
        this.classList.toggle('active');
        
        // Add pop animation
        this.style.transform = 'scale(1.2)';
        setTimeout(() => {
            this.style.transform = 'scale(1)';
        }, 200);

        icon.classList.toggle('far');
        icon.classList.toggle('fas');
        icon.classList.toggle('text-danger');
    });
});

// Handle category selection
document.querySelectorAll('.category-box').forEach(box => {
    box.addEventListener('click', function() {
        document.querySelectorAll('.category-box').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
    });
});

// Handle filter button selection
document.querySelectorAll('.scrolling-wrapper .btn').forEach(button => {
    button.addEventListener('click', function() {
        const wasActive = this.classList.contains('active');
        document.querySelectorAll('.scrolling-wrapper .btn').forEach(b => b.classList.remove('active'));
        if (!wasActive) {
            this.classList.add('active');
        }
    });
});

// Implement search functionality
const searchInput = document.querySelector('.search-input');
if (searchInput) {
    let timeout = null;
    searchInput.addEventListener('input', function(e) {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            // Add loading state
            const cards = document.querySelectorAll('.tour-card');
            cards.forEach(card => card.classList.add('loading'));
            
            // Simulate search delay
            setTimeout(() => {
                const searchTerm = e.target.value.toLowerCase();
                cards.forEach(card => {
                    const title = card.querySelector('.card-title').textContent.toLowerCase();
                    const location = card.querySelector('.location-time').textContent.toLowerCase();
                    
                    if (title.includes(searchTerm) || location.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                    card.classList.remove('loading');
                });
            }, 500);
        }, 300);
    });
}

// Handle bottom navigation
document.querySelectorAll('.bottom-nav a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('.bottom-nav a').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
    });
});

// Add smooth scrolling for category and filter sections
document.querySelectorAll('.scrolling-wrapper').forEach(wrapper => {
    let isDown = false;
    let startX;
    let scrollLeft;

    wrapper.addEventListener('mousedown', (e) => {
        isDown = true;
        wrapper.classList.add('active');
        startX = e.pageX - wrapper.offsetLeft;
        scrollLeft = wrapper.scrollLeft;
    });

    wrapper.addEventListener('mouseleave', () => {
        isDown = false;
        wrapper.classList.remove('active');
    });

    wrapper.addEventListener('mouseup', () => {
        isDown = false;
        wrapper.classList.remove('active');
    });

    wrapper.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - wrapper.offsetLeft;
        const walk = (x - startX) * 2;
        wrapper.scrollLeft = scrollLeft - walk;
    });
});

// Add loading state when clicking Book Now
document.querySelectorAll('.btn-primary').forEach(button => {
    button.addEventListener('click', function() {
        const originalText = this.textContent;
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...';
        
        // Simulate API call
        setTimeout(() => {
            this.disabled = false;
            this.textContent = originalText;
            // Show success message
            showToast('Booking successful!');
        }, 1500);
    });
});

// Toast notification function
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
} 