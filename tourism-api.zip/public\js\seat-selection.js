document.addEventListener('DOMContentLoaded', function() {
    // Get flight data from session storage
    const flightData = JSON.parse(sessionStorage.getItem('selectedFlight') || '{}');
    
    // Handle seat selection
    const seats = document.querySelectorAll('.seat:not(.reserved)');
    let selectedSeat = document.querySelector('.seat.selected');

    seats.forEach(seat => {
        seat.addEventListener('click', function() {
            if (this.classList.contains('reserved')) return;
            
            // Remove previous selection
            if (selectedSeat) {
                selectedSeat.classList.remove('selected');
            }
            
            // Select new seat
            this.classList.add('selected');
            selectedSeat = this;
        });
    });

    // Handle confirm button
    const confirmButton = document.querySelector('.confirm-btn');
    confirmButton.addEventListener('click', function() {
        const selectedSeat = document.querySelector('.seat.selected');
        if (!selectedSeat) {
            alert('Please select a seat');
            return;
        }

        // Add seat information to flight data
        flightData.seat = selectedSeat.dataset.seat;
        sessionStorage.setItem('selectedFlight', JSON.stringify(flightData));

        // Redirect to payment page
        window.location.href = 'payment.html';
    });
}); 