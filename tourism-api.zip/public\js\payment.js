document.addEventListener('DOMContentLoaded', function() {
    // Get flight data from session storage
    const flightData = JSON.parse(sessionStorage.getItem('selectedFlight') || '{}');
    
    // Update flight summary
    if (flightData.airline) {
        document.querySelector('.airline-logo').src = `images/airlines/${flightData.airline.toLowerCase()}.png`;
    }
    if (flightData.departure) {
        document.querySelector('.col-5:first-child .time').textContent = flightData.departure.time;
        document.querySelector('.col-5:first-child .location').textContent = flightData.departure.location;
    }
    if (flightData.arrival) {
        document.querySelector('.col-5:last-child .time').textContent = flightData.arrival.time;
        document.querySelector('.col-5:last-child .location').textContent = flightData.arrival.location;
    }
    if (flightData.price) {
        document.querySelector('.total-amount').textContent = flightData.price;
    }

    // Format card number input
    const cardNumber = document.getElementById('card-number');
    cardNumber.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 16) value = value.slice(0, 16);
        const parts = value.match(/[\s\S]{1,4}/g) || [];
        e.target.value = parts.join(' ');
    });

    // Format expiry date input
    const expiry = document.getElementById('expiry');
    expiry.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 4) value = value.slice(0, 4);
        if (value.length > 2) {
            value = value.slice(0, 2) + '/' + value.slice(2);
        }
        e.target.value = value;
    });

    // Format CVV input
    const cvv = document.getElementById('cvv');
    cvv.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 3) value = value.slice(0, 3);
        e.target.value = value;
    });

    // Handle form submission
    const confirmButton = document.querySelector('.confirm-btn');
    confirmButton.addEventListener('click', function() {
        // Validate inputs
        const cardHolder = document.getElementById('card-holder');
        
        if (!cardNumber.value || cardNumber.value.replace(/\s/g, '').length !== 16) {
            alert('Please enter a valid card number');
            cardNumber.focus();
            return;
        }
        if (!cardHolder.value) {
            alert('Please enter the card holder name');
            cardHolder.focus();
            return;
        }
        if (!cvv.value || cvv.value.length !== 3) {
            alert('Please enter a valid CVV');
            cvv.focus();
            return;
        }
        if (!expiry.value || !expiry.value.includes('/')) {
            alert('Please enter a valid expiry date');
            expiry.focus();
            return;
        }

        // Add payment information to flight data
        flightData.payment = {
            cardNumber: cardNumber.value.replace(/\s/g, ''),
            cardHolder: cardHolder.value,
            expiry: expiry.value,
            cvv: cvv.value
        };
        sessionStorage.setItem('selectedFlight', JSON.stringify(flightData));

        // Redirect to boarding pass
        window.location.href = 'boarding-pass.html';
    });

    // Handle cancel button
    const cancelButton = document.querySelector('.cancel-btn');
    cancelButton.addEventListener('click', function() {
        if (confirm('Are you sure you want to cancel this payment?')) {
            window.location.href = 'flight-results.html';
        }
    });
}); 